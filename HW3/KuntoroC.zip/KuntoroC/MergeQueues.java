import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;

public class MergeQueues {
    // Return true if v is less than w and false otherwise.
    private static boolean less(Comparable v, Comparable w) {
        return v.compareTo(w) < 0;
    }

    // Merge and return the two sorted queues as a single sorted queue.
    private static Queue<Comparable> merge(Queue<Comparable> q1,
                                           Queue<Comparable> q2) {

        //Create the Queue to store the merged objects
        Queue<Comparable> mergedAll = new Queue<>();

        //Create an iterator for each queue to access the objects within the queue
        Iterator<Comparable> q1Iterator = q1.iterator();
        Iterator<Comparable> q2Iterator = q2.iterator();

        //The first call of the next method (according to the Princeton API) returns the first node
        //Store it into a Comparable object for each of them
        Comparable q1ComparableObject = q1Iterator.next();
        Comparable q2ComparableObject = q2Iterator.next();

        //To avoid checking an empty array with an array that has something in it, both objects must not be null
        while ((q1ComparableObject != null) && (q2ComparableObject != null)) {

            //Comparing: if the object in q1 is smaller than q2's
            if (less(q1ComparableObject, q2ComparableObject)) {
                //add q1 to mergedAll
                mergedAll.enqueue(q1ComparableObject);

                //Call next again on q1ComparableObject if there are any objects left
                if (q1Iterator.hasNext()) {
                    q1ComparableObject = q1Iterator.next();
                }

                //Otherwise, set q1ComparableObject to null
                else {
                    q1ComparableObject = null;

                }

                //Comparing: if the object in q2 is smaller than q1's
            } else if (less(q2ComparableObject, q1ComparableObject)) {

                //add q2 to mergedAll
                mergedAll.enqueue(q2ComparableObject);

                //Checking if q2 has anymore objects left
                if (q2Iterator.hasNext()) {

                    //If so, set the current object to the next object
                    q2ComparableObject = q2Iterator.next();
                } else {

                    //Otherwise, set q2ComparableObject to null
                    q2ComparableObject = null;

                }
                //If the objects at q1 and q2 are equal
            } else {

                //Add q1's object first
                mergedAll.enqueue(q1ComparableObject);

                //Checking if q1 has anymore objects left
                if (q1Iterator.hasNext()) {

                    //If so, set the current object to the next object
                    q1ComparableObject = q1Iterator.next();
                } else {

                    //Otherwise, set q1ComparableObject to null
                    q1ComparableObject = null;
                }

                //then add q2's object
                mergedAll.enqueue(q2ComparableObject);

                //Checking if q2 has anymore objects left
                if (q2Iterator.hasNext()) {

                    //If so, set the current object to the next object
                    q2ComparableObject = q2Iterator.next();
                } else {

                    //Otherwise, set q2ComparableObject to null
                    q2ComparableObject = null;
                }
            }
        }
        //If there are any q1 Objects remaining, put all the remaining objects to mergedAll
        while (q1ComparableObject != null) {

            mergedAll.enqueue(q1ComparableObject);

            //If q1 has another object, set the current object to the next one
            if (q1Iterator.hasNext()) {
                q1ComparableObject = q1Iterator.next();
            }
            //Otherwise, set q1ComparableObject to null
            else {
                q1ComparableObject = null;
            }
        }

        //If there are any q2 Objects remaining, put all the remaining objects to mergedAll
        while (q2ComparableObject != null) {

            mergedAll.enqueue(q2ComparableObject);

            //If q1 has another object, set the current object to the next one
            if (q2Iterator.hasNext()) {
                q2ComparableObject = q2Iterator.next();
            } else {

                //Otherwise, set q1ComparableObject to null
                q2ComparableObject = null;
            }
        }

        //Return the fully merged Queue
        return mergedAll;
    }

    // Test client. [DO NOT EDIT]
    public static void main(String[] args) {
        String[] a = {"A", "B", "C", "D", "E", "F", "G", "H", "I",
                "J", "K", "L", "M", "N", "O", "P", "Q", "R",
                "S", "T", "U", "V", "W", "X", "Y", "Z"};
        Queue<Comparable> q1 = new Queue<Comparable>();
        Queue<Comparable> q2 = new Queue<Comparable>();

        for (String s : a) {
            if (StdRandom.bernoulli(0.5)) {
                q1.enqueue(s);
            } else {
                q2.enqueue(s);
            }
        }
        int s1 = q1.size(), s2 = q2.size();
        StdOut.println(merge(q1, q2));
        assert q1.size() == s1 && q2.size() == s2;
    }
}
